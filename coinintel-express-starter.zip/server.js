
const express = require('express');
const app = express();
const path = require('path');

app.use(express.static('public'));

app.get('/api/roi', (req, res) => {
  res.json({
    roiData: [2.3, 2.6, 3.1, 3.9, 4.4, 4.9, 5.3]
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
